/**
 * Created by user on 22.09.2017.
 */
public interface Collection {

        void add(String element);



}
