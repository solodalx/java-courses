package ru.sbt.javacourse.class02;


import java.lang.reflect.Method;

/**
 * Created by user on 13.10.2017.
 */
public class ReflectionUtils {

    public static void printMethodNames(Class<?> clazz) {
        Method[] methods = clazz.getMethods();
        for (Method method : methods) {
            if (method.getParameterCount() > 1 && method.getReturnType() == String.class)
                System.out.println(method.getName());

        }
    }



}
