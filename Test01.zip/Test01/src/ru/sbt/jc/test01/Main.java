package ru.sbt.jc.test01;

/**
 * Created by user on 06.10.2017.
 */
public class Main {
    public static void main(String[] args) {

        int d = 0;


    }



}
