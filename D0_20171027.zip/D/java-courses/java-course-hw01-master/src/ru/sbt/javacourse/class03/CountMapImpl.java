package ru.sbt.javacourse.class03;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by user on 27.10.2017.
 */
public class CountMapImpl <T> implements CountMap <T> {

    Map<T, Integer> map = new HashMap<>();

    public Map<T, Integer> getMap() {
        return map;
    }

    @Override
    public void add(T o) {
        Integer count = map.get(o);
        if (count == null) count = 0;
        map.put(o, count + 1);
    }

    @Override
    public int getCount(T o) {
        Integer count = map.get(o);
        return count == null ? 0: count;
    }

    @Override
    public int size() {
        return map.size();
    }

    @Override
    public void addAll(CountMap<? extends T> source) {
        source
    }


}
