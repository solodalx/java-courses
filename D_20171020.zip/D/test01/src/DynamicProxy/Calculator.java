package DynamicProxy;

public interface Calculator {
    @Cache (expireInSec = 100)
    public int calc(int arg);

    @Cache
    public int calc2(int arg);

    public int calc3(int arg);
}
