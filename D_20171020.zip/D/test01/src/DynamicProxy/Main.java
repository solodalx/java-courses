package DynamicProxy;

import static DynamicProxy.CacheProxy.withCache;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        Calculator calculator = withCache(new SimpleCalculator());

        calculator.calc(10);
        calculator.calc(15);
        calculator.calc(15);
        calculator.calc(10);


        Thread.sleep(50);
        calculator.calc(10);

        Thread.sleep(100);
        calculator.calc(10);
    }


}
