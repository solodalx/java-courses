package ru.sbt.exchange.client;

import ru.sbt.exchange.domain.*;
import ru.sbt.exchange.domain.instrument.Bond;
import ru.sbt.exchange.domain.instrument.Instrument;
import ru.sbt.exchange.domain.instrument.Instruments;

import java.util.List;
import java.util.Objects;

public class MyAlgoStrategy implements AlgoStrategy {
    int counter = 0;

    @Override
    public void onEvent(ExchangeEvent event, Broker broker) {
//        PeriodInfo periodInfo = broker.getPeriodInfo();
//        TopOrders ordersZero = broker.getTopOrders(Instruments.zeroCouponBond());
//        TopOrders ordersFixed = broker.getTopOrders(Instruments.fixedCouponBond());
//        TopOrders ordersFloating = broker.getTopOrders(Instruments.floatingCouponBond());
//
//        Portfolio portfolio = broker.getMyPortfolio();
//        List<Order> myOrders = broker.getMyLiveOrders();
//
//        if (event.getExchangeEventType() == ExchangeEventType.STRATEGY_START) {
//        }
//
//        if (event.getExchangeEventType() == ExchangeEventType.NEW_PERIOD_START) {
//        }

        Order order = event.getOrder();
        Instrument instrument = order.getInstrument();
        double nominal = ((Bond)order.getInstrument()).getNominal();

//        boolean isMyOrder = false;
//        for (Order o: myOrders) {
//            if (Objects.equals(order.getOrderId(), o.getOrderId())) {
//                isMyOrder = true;
//                break;
//            }
//        }

        if (event.getExchangeEventType() == ExchangeEventType.ORDER_NEW) {
//            if (!isMyOrder) {
                if (order.getDirection() == Direction.BUY && order.getPrice() > nominal) {
                    broker.addOrder(order.opposite());
                } else if (order.getDirection() == Direction.SELL && order.getPrice() < nominal) {
                    broker.addOrder(order.opposite());
                }
//            }
        }

//        if (event.getExchangeEventType() == ExchangeEventType.ORDER_EXECUTION) {
//        }
//
//        if (event.getExchangeEventType() == ExchangeEventType.ORDER_EVICT) {
//        }

//        Random random = new Random();
//        broker.addOrder(Order.buy(Instruments.zeroCouponBond()).withPrice(random.nextInt(100)).withQuantity(10).order());
//        broker.addOrder(Order.sell(Instruments.zeroCouponBond()).withPrice(random.nextInt(100)).withQuantity(10).order());
    }
}