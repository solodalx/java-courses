import sun.reflect.generics.scope.MethodScope;
import supertest.RunMe;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;

/**
 * Created by user on 13.10.2017.
 */
public class ReflectionUtils {

    public List<Method> allMethods(Class<?> clazz) {
        List<Method> list = new ArrayList<Method>();
        Class cl = clazz;

        while (cl != null) {
//            Method[] methods = cl.getDeclaredMethods();
            list.addAll(asList(cl.getDeclaredMethods()));
/*
            for (Method method : methods) {
                list.add(method);
            }
*/
            cl = cl.getSuperclass();

        }

        return list;
    }

    public void PrintList(List<Method> list) {
        for (Method method : list) {
            System.out.println(method.getName());
        }

    }

    public static void printMethodNames(Class <?> clazz) {
        Method[] methods = clazz.getMethods();

        for (Method method : methods){
            if (method.getParameterCount() > 1 && method.getReturnType() == String.class)
                System.out.println(method.getName());
        }

    }

    @RunMe
    public void method1 (){
        return;
    }

    @RunMe
    public void method2 (int n){
        return;
    }

    @RunMe
    public int method3 (){
        return 0;
    }

    @RunMe
    public void method4 (int n){
        return;
    }

    @RunMe
    public void method5 (int n, String s){
        return;
    }

}
