package ru.sbt.javacourse.class03;

/**
 * Created by user on 27.10.2017.
 */
public interface CountMap <T> {
    void add(T o);
    int getCount(T o);
    int size();
    void addAll(CountMap<? extends T> source);
}
