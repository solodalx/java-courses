package ru.sbt.javacourse.class05;

import ru.sbt.javacourse.hw01.Person;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Created by user on 08.12.2017.
 */
public class Streams<T> {

    private final List<? extends T> list;

    public Streams(List<? extends T> list) {
        this.list = list;
    }

    public static<T> Streams<T> of(List<? extends T> list) {
        return new Streams<>(list);
    }

    Streams<T> filter(Predicate<? super T> predicate) {
        List<T> result = new ArrayList<>();
        for (T t: list) {
            if (predicate.test(t)) {
                result.add(t);
            }
        }
        return new Streams<>(result);
    }

    public<K> Streams<K> transform(Function<? super T, ? extends K> function) {
        List<K> result = new ArrayList<>();
        for (T t: list) {
            result.add(function.apply(t));
        }
        return new Streams<>(result);
    }

    public<K, V> Map<K, V> toMap(Function<? super T, ? extends K> key, Function<? super T, ? extends V> value) {
        Map<K, V> map = new HashMap<>();
        for (T t: list) {
            map.put(key.apply(t), value.apply(t));
        }
        return map;
    }

}



