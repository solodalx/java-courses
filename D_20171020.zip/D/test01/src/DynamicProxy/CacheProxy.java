package DynamicProxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.*;

import static java.lang.ClassLoader.getSystemClassLoader;
import static java.lang.reflect.Proxy.newProxyInstance;

public class CacheProxy implements InvocationHandler {

    final private Object delegate;
    final private Map<ArrayList<Object>, Result> cache;

    class Result {
        long created;
        Object result;

        Result(long created, Object result) {
            this.created = created;
            this.result = result;
        }
    };

    private CacheProxy(Object delegate) {
        this.delegate = delegate;
        cache = new HashMap<ArrayList<Object>, Result>();
    }

    public static <T> T withCache(Object delegate) {
        return (T) newProxyInstance(
                getSystemClassLoader(),
                delegate.getClass().getInterfaces(),
                new CacheProxy(delegate)
        );
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.print("Input: " + method.getName() + ". ");
        Cache annotation = method.getAnnotation(Cache.class);
        int expireInSec = annotation != null ? annotation.expireInSec() : -2;

        ArrayList<Object> key = getKey(method, args);
        if (cache.containsKey(key)) {
            Result result = cache.get(key);
            long now = new Date().getTime();
//            System.out.print("Created: " + result.created + ", now: " + now + ", time: " + (now - result.created) + ", expire: " + expireInSec + ". ");
            if (expireInSec == -1 || now - result.created < expireInSec) {
                System.out.println("Result from cache: " + result.result);
                return result.result;
            }
        }

        Object result = method.invoke(delegate, args);
        cache.put(key, new Result(new Date().getTime(), result));
        System.out.println("Result: " + result);

        return result;
    }

    private ArrayList<Object> getKey(Method method, Object[] args) {
        ArrayList<Object> key = new ArrayList<Object>();
        key.add(method.getName());
        if (args != null) {
            Collections.addAll(key, args);
        }
        System.out.print("Key: " + key + ". ");
        return key;
    }
}
