package ru.sbt.javacourse.class04;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * Created by user on 10.11.2017.
 */
public class Main {
    public static void main(String[] args) throws ClassNotFoundException {

//        AlgoStrategyClassloader cl = new AlgoStrategyClassloader("c:/strategies/", "alex", Main.class.getClassLoader());

        for (int i = 0; i < 1_000_000; i++) {
            AlgoStrategyClassloader cl = new AlgoStrategyClassloader("c:/strategies/", "alex", null);
            cl.loadClass("ru.sbt.javacourse.class04.MyAlgoStrategy");
        }

    }

}
