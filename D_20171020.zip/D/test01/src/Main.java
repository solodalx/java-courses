
import supertest.TestRunner;

import java.lang.reflect.InvocationTargetException;

public class Main {

    public static void main(String[] args) throws IllegalAccessException, InvocationTargetException, InstantiationException {
//        ReflectionUtils/**/.printMethodNames(Integer.class);

        /*ReflectionUtils ref = new ReflectionUtils();
        ref.PrintList(ref.allMethods(Integer.class));
        */

         TestRunner.runTest(ReflectionUtils.class);

    }


}
