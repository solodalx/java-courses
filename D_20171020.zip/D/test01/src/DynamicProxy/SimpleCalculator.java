package DynamicProxy;

public class SimpleCalculator implements Calculator {
    @Override
    public int calc(int param) {
        return param + 10;
    }

    @Override
    public int calc2(int param) {
        return param + 11;
    }

    @Override
    public int calc3(int param) {
        return param + 12;
    }
}
