package ru.sbt.javacourse.class05;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Created by user on 08.12.2017.
 */
public class Main {

    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(3, 5, 7, 9, 11);

        List<Person2> persons = Arrays.asList(
                new Person2("Aaa", 11),
                new Person2("Bbb", 22),
                new Person2("Ccc", 33));

        Map<String, Person2> map = null;

        map = Streams.of(persons)
                .filter(p -> p.getAge() > 20)
                .transform(p -> new Person2("Mr. " + p.getName(), p.getAge() + 10))
                .toMap(p -> p.getName(), p -> p);

        for (String s : map.keySet()) {
        Person2 p = map.get(s);
        System.out.println(p.getName() + " " + p.getAge());
        }
    }
}
