/**
 * Created by user on 06.10.2017.
 */
public interface Stack {
    Integer get();

    void add(Integer i);

}


