package supertest;

//import static org.junit.Assert.*;

/**
 * Created by user on 13.10.2017.
 */
/*
public class TestRunnerTest {
    @org.junit.Test
    public void runTest() throws Exception {

        TestRunner.runTest(ReflectionUtils.class);

    }

}*/
