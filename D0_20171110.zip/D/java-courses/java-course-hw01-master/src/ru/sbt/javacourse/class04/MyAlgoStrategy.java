package ru.sbt.javacourse.class04;

/**
 * Created by user on 10.11.2017.
 */
public class MyAlgoStrategy {


}
