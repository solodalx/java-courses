package ru.sbt.javacourse.class04;

import com.sun.deploy.util.StringUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by user on 10.11.2017.
 */
public class AlgoStrategyClassloader extends ClassLoader {

    String path;
    String student;

    public AlgoStrategyClassloader(String path, String student, ClassLoader parent) {
        super(parent);
        this.path = path;
        this.student = student;
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {

        byte[] b = null;
//        Path file = Paths.get(path + student + "/" + name.replace('.', '/') + ".class");
        Path file = Paths.get(path + student + "/ru/sbt/MyAlgoStrategy.class");
        try {
            b = Files.readAllBytes(file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return defineClass(name, b, 0, b.length);
    }
}
