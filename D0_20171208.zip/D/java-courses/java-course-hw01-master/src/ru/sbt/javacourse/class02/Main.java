package ru.sbt.javacourse.class02;

/**
 * Created by user on 13.10.2017.
 */
public class Main {
    public static void main(String[] args) {
        ReflectionUtils.printMethodNames(String.class);
    }


}
