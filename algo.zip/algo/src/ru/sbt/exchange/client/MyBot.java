package ru.sbt.exchange.client;

import ru.sbt.exchange.domain.Direction;
import ru.sbt.exchange.domain.ExchangeEvent;
import ru.sbt.exchange.domain.ExchangeEventType;
import ru.sbt.exchange.domain.Order;
import ru.sbt.exchange.domain.instrument.Bond;
import ru.sbt.exchange.domain.instrument.Instrument;
import ru.sbt.exchange.domain.instrument.Instruments;

import java.util.Random;

public class MyBot implements AlgoStrategy {
    int counter = 0;

    @Override
    public void onEvent(ExchangeEvent event, Broker broker) {
        Random random = new Random();
        broker.addOrder(Order.buy(Instruments.zeroCouponBond()).withPrice(random.nextInt(150)).withQuantity(10).order());
        broker.addOrder(Order.sell(Instruments.zeroCouponBond()).withPrice(random.nextInt(150)).withQuantity(10).order());
    }
}