package xml;

/**
 * Created by user on 13.10.2017.
 */
public class Person {
    public String name;
    public int age;
}
