import java.util.Queue;

/**
 * Created by user on 22.09.2017.
 */
public class Main {
    Queue<Integer>;

    De
}

