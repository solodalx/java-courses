package ru.sbt.javacourse.class05;

import org.junit.jupiter.api.Test;

//import static org.junit.Assert.*;

/**
 * Created by user on 08.12.2017.
 */
public class StreamTest {
    @Test
    public void condition() throws Exception {
    }

}