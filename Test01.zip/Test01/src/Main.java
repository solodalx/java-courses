/**
 * Created by user on 06.10.2017.
 */
public class Main {
    public static void main(String[] args) {
        StackImpl s = new StackImpl(5);

        s.add(3);
        s.add(5);
        s.add(7);
        s.add(6);

        System.out.println(s.get());
        System.out.println(s.get());
        s.ToString();

    }

}
