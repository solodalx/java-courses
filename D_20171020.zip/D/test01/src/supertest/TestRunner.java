package supertest;

import javafx.collections.transformation.SortedList;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static java.util.Arrays.asList;

/**
 * Created by user on 13.10.2017.
 */
public class TestRunner {
    public static void runTest (Class<?> testClass) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Object o = testClass.newInstance();

        List<Method> testMethods = findTestMethods(testClass);

        for (Method testMethod : testMethods) {
            try {
                System.out.print("Try method:" + testMethod.getName());
                testMethod.invoke(o);
                System.out.println(" - Invoke OK");
            } catch (IllegalArgumentException e) {
                System.out.println(" - Failed. Exception: " + e);
            }
        }
    }



    private static List<Method> findTestMethods(Class<?> clazz) {
        List<Method> list = new ArrayList<Method>();
//        List<Method> list = new SortedList<Method>(l);

        /*Comparator<Method> c = new Comparator<Method>() {
            @Override
            public int compare(Method o1, Method o2) {
                return o1.getName().compareTo(o2.getName());
            }
        };
*/

        Method[] methods = clazz.getDeclaredMethods();
//        list.sort(c);
        for (Method method : methods){
            if (   method.isAnnotationPresent(RunMe.class)
                && method.getParameterCount() >= 0
                && method.getReturnType() == void.class
               ) {

                list.add(method);
//                System.out.println(method.getName());
            }

        }

//        Method m = null;
//        boolean annotationPresent = m.isAnnotationPresent(RunMe.class);
        return list;
    }

}
