public class circle {
    double R;
    int x;

    public double area() { return 3.14*R*R; }
}
