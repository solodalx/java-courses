package xml;

/**
 * Created by user on 13.10.2017.
 */
public class Main {

    public static void main(String[] args) {

//        Person person = new Person("Alex", 10);

//        String xml = new

    }

}
