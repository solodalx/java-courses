public class Rectangle {
    double a;
    double b;

    public double area() {  return a*b; }
}
