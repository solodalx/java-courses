package ru.sbt.exchange;


import ru.sbt.exchange.client.MyAlgoStrategy;
import ru.sbt.exchange.client.MyBot;
import ru.sbt.exchange.repository.portfolio.StaticPortfolioFactory;

/**
 * Created by user on 01.12.2017.
 */
public class Runner {
    public static void main(String[] args) {
        AlgoLocalRunner algoLocalRunner = new AlgoLocalRunner();
        algoLocalRunner.runServer(20, 2, new StaticPortfolioFactory());
        algoLocalRunner.runClient("alex", new MyAlgoStrategy());
        algoLocalRunner.runClient("bot", new MyBot());
    }
}
