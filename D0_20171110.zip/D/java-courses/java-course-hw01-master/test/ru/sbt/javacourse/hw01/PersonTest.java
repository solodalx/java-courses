package ru.sbt.javacourse.hw01;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Created by user on 29.09.2017.
 */
class PersonTest {

    @Test
    public void testMarry(){
        Person m = new Person(true, "m");
        Person w = new Person(false, "w");

        m.marry(w);

        assertEquals(w, m.getSpouse());
        assertEquals(m, w.getSpouse());

    }

    @Test
    public void marryPersonWithSameGenter() {
        Person p1 = new Person(true, "A");
        Person p2 = new Person(true, "B");

//        boolean marry = p1.marry(p2);
//        assertEquals(false, marry);
        assertFalse(p1.marry(p2));
        assertFalse(p2.marry(p1));

    }

    @Test
    public void testMarryWithDivorse() {
        Person m1 = new Person(true, "m1");
        Person w1 = new Person(false, "w1");
        m1.marry(w1);

        Person m2 = new Person(true, "m2");
        w1.marry(m2);

        assertEquals(null, m1.getSpouse());
        assertEquals(m2, w1.getSpouse());
        assertEquals(w1, m2.getSpouse());

        assertFalse(w1.marry(m2));
    }

}