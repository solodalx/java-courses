package ru.sbt.exchange.domain.instrument;

import java.io.Serializable;

public interface Instrument extends Serializable {
    String getName();
}
