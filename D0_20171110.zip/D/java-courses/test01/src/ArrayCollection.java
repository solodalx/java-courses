/**
 * Created by user on 22.09.2017.
 */
public class ArrayCollection implements Collection {


    @Override
    public void add(String element) {

    }
}
