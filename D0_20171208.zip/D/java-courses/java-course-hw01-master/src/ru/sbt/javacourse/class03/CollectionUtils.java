package ru.sbt.javacourse.class03;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 27.10.2017.
 */
public class CollectionUtils {

    public static <T> T nonNull(T o) {
        if (o == null)
            throw new NullPointerException();
        return o;
    }

    public static <T> List<T> join(List<? extends T> list, List<? extends T> list2) {
        List<T> result = new ArrayList<>();

        result.addAll(list);
        result.addAll(list2);

        return result;
    }

    public static <T> void addAll(List<? super T> destination, List<? extends T> source) {
        destination.addAll(source);
    }


}
