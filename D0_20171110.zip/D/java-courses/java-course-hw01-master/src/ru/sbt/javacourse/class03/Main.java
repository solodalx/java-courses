package ru.sbt.javacourse.class03;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by user on 27.10.2017.
 */
public class Main {
    public static void main(String[] args) {
        Integer integer = null;
        String string = null;

        /*try {
            System.out.println(CollectionUtils.nonNull(integer));
        } catch (Exception e) {
            System.out.println("integer exception");
        }
        try {
            System.out.println(CollectionUtils.nonNull(string));
        } catch (Exception e) {
            System.out.println("string exception");
        }
        integer = 5;
        System.out.println(CollectionUtils.nonNull(integer));
        System.out.println(CollectionUtils.nonNull(new Integer(5)));
        System.out.println(CollectionUtils.nonNull("Hello!"));
*/

        List<Integer> l1 = Arrays.asList(3, 5, 7);
        List<Double> l2 = Arrays.asList(6., 4.4, 2.);
        System.out.println(CollectionUtils.join(l1, l2));
        /*System.out.println(CollectionUtils.join(Arrays.asList(3, 5, 7), Arrays.asList(6, 4, 2)));
        System.out.println(CollectionUtils.join(Arrays.asList("A ", "C ", "E "), Arrays.asList("F ", "D ", "B ")));
*/
/*
        List<Integer> integerList = new ArrayList<>(Arrays.asList(3, 5, 7));
        CollectionUtils.addAll(integerList, Arrays.asList(6, 4, 2));
        System.out.println(integerList);

        List<String> stringList = new ArrayList<>(Arrays.asList("A ", "C ", "E "));
        CollectionUtils.addAll(stringList, Arrays.asList("F ", "D ", "B "));
        System.out.println(stringList);
*/
    }
}
