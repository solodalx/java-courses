package ru.sbt.javacourse.class05;

/**
 * Created by user on 08.12.2017.
 */
public interface MyPredicate {
    public boolean condition();
}
